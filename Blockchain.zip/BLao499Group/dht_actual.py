from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15, pss
from Crypto.Hash import SHA256
from time import time

import json
from urllib.parse import urlparse
from uuid import uuid4

import requests
from flask import Flask, jsonify, request
import sys

import random
import ast

from dht_chain_actual import Blockchain

#Adding content a node:
#Node on the DHT sends a request to the mint
#Mint takes the content, makes a blockchain of it, and assigns it to a hash
#Assigns the access key of the blockchain to the public key of the request DHT node

#Editing a node
#Node on the DHT sends a request to the mint
#Mint checks the signature, verifies it, and makes the edit
#Mines, rehashes, and sends the new hash back to the node

#Accessing content from the mint can work as a DHT

files = {}

app = Flask(__name__)
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = False
node_identifier = str(uuid4()).replace('-','')

@app.route('/addContent', methods=['POST'])
def Add_Content():

	print("Received")
	new_chain = Blockchain()
	values = request.get_json()
	fat = []

	required = ['nodelist', 'filename']
	if not all (k in values for k in required):
		return 'Missing values', 400

	for i in values['nodelist']:
		url = i['node'] + "addContent"
		data = {"content": i['content'], "blockchain": new_chain.chain}
		headers = {'Content-type': 'application/json', 'Accept': 'json,application/text/plain'}

		response=requests.post(url, data=json.dumps(data), headers=headers)
		if (response.status_code == 500):
			return 'Failed to add', 500

		#Get the public key of the node we just sent to
		pubkeyfile = i['node'] + "public.pem"
		pubkeyfile = pubkeyfile.replace("http://", "")
		pubkeyfile = pubkeyfile.replace(":", "")
		pubkeyfile = pubkeyfile.replace("/", "")

		pubKey = RSA.import_key(open(pubkeyfile).read())
		verifier = pss.new(pubKey)
		signature = response.content

		url = i['node'] + "returnTempchain"
		response = requests.get(url)
		received = response.json()
		blockHash = new_chain.hash(received['content'][-1])

		#Verify signature
		try:
			verifier.verify(blockHash, signature)
			print("Signature verified")
		except (ValueError, TypeError):
			return "Bad signature", 400
		if new_chain.validate_chain(received['content']) is False:
			print("Failed to validate")
			return "Failed validation", 400
		new_chain.chain = received['content']
		fat.append({
			'node': new_chain.last_block['transactions']['changes'][-1]['node'],
			'hash': new_chain.last_block['transactions']['changes'][-1]['hash']
			})

	files[values['filename']] = {'blockchain': new_chain, 'FAT': fat}

	response = {'message': 'added', 'blockchain': new_chain.chain, 'fat': fat}

	return jsonify(response), 200

@app.route('/accessContent', methods=['POST'])
def Access_Content():
	values = request.get_json()
	finalStr = ""

	required = ['filename']
	if not all (k in values for k in required):
		return 'Missing values', 400

	try:
		accessed_chain = files[values['filename']]
	except IndexError:
		return 'Invalid index', 400

	for i in accessed_chain['FAT']:
		url = "http://" + i['node'] + "/returnContent"
		data = {"content-hash": i['hash']}
		headers = {'Content-type': 'application/json', 'Accept': 'json,application/text/plain'}

		response=requests.post(url, data=json.dumps(data), headers=headers)
		received = response.json()

		finalStr += received['content']

	response = {'access': finalStr}
	return jsonify(response), 200


if __name__ == '__main__':
	from argparse import ArgumentParser

	print("Type in port")
	portNum = input()
	parser = ArgumentParser()
	parser.add_argument('-p', '--port', default=portNum, type=int, help='port to listen on')
	args = parser.parse_args()
	port = args.port

	app.run(host='127.0.0.1', port=port)