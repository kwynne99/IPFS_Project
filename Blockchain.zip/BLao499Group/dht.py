from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15, pss
from Crypto.Hash import SHA256
from time import time

import json
from urllib.parse import urlparse
from uuid import uuid4

import requests
from flask import Flask, jsonify, request, redirect
import sys

import random
import ast

from dht_chain_actual import Blockchain

class DHT_Node:
	def __init__(self):
		self.nextNode = ""
		self.prevNode = ""
		self.content = {}
		self.tempChain = Blockchain()

app = Flask(__name__)
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = False
node_identifier = str(uuid4()).replace('-','')

serverNode = DHT_Node()

@app.route('/addNode', methods=['POST'])
def New_Node():
	values = request.get_json()

	required = ['node']
	if not all (k in values for k in required):
		return 'Missing node', 400
	serverNode.nextNode = values['node']
	#Message node to add to prevNode?

	response = {'message': 'node added to DHT chain'}
	return jsonify(response), 200

#Modify block hash function so that it's similar to bookchain's hashing for blocks
#When we get a request to add content, open file, find closest cluster we can modify
#Note cluster's index, make modification
#Hash the index:content, add it to the transactions, mine
#Send the mined chain back, main node verifies then continues
@app.route('/addContent', methods=['POST'])
def Add_Content():
	values = request.get_json()
	tempChain = Blockchain()

	required = ['content', 'blockchain']
	if not all (k in values for k in required):
		return 'Missing values', 400

	tempChain.chain = values['blockchain']
	contentHash = SHA256.new(values['content'].encode())

	f = open(filename, 'r')
	disk = f.read()
	f.close()
	diskIndex = disk.find("@@ ")
	if diskIndex == -1:
		return 'No disk space', 400
	disk = disk.replace("@@", values['content'], 1)
	print("Index:")
	print(diskIndex)
	print("Content:")
	print(disk[diskIndex:diskIndex+2])
	f = open(filename, 'w')
	f.write(disk)
	f.close()

	tempChain.chain = values['blockchain']
	contentHash = SHA256.new((values['content'] + str(diskIndex)).encode()).hexdigest()
	tempChain.new_transaction(request.host, contentHash, "add")
	proof = tempChain.proof_of_work(tempChain.chain[-1])
	prevHash = tempChain.hash(tempChain.chain[-1]).hexdigest()
	tempChain.new_block(proof, prevHash)

	serverNode.tempChain = tempChain
	serverNode.content[contentHash] = diskIndex

	#TD, hash the temp Chain and send that over, dht_actual
	#receives signature, fetches the temp chain, checks signature
	#Creates signature of the hash; only returns the signature
	blockHash = tempChain.hash(tempChain.last_block)
	privatefile = request.host + "private.pem"
	privatefile = privatefile.replace(":", "")
	f = open(privatefile, 'r')
	private_key = RSA.import_key(f.read())
	f.close()
	signature = pss.new(private_key).sign(blockHash)
	print("New signature")
	print(signature)

	#response = {"message": f"Hash {ob_hash} added", "hash": ob_hash, "sig":signature}
	return signature, 200

@app.route('/returnTempchain', methods=['GET'])
def Return_Tempchain():
	response = {
		'content': serverNode.tempChain.chain
	}
	return jsonify(response), 200

@app.route('/returnContent', methods=['POST'])
def Return_Content():
	values = request.get_json()

	required = ['content-hash']
	print(values['content-hash'])
	if not all (k in values for k in required):
		return 'Missing values', 400

	try:
		returnContent = serverNode.content[values['content-hash']]
	except KeyError:
		if serverNode.nextNode == "":
			response = {"message": "hash not found"}
			return jsonify(response), 404

		# response = {"next-node": serverNode.nextNode}
		# return jsonify(response), 303
		redirectUrl = serverNode.nextNode + "/returnContent"
		return redirect(redirectUrl, code=307)

	f = open(filename, 'r')
	disk = f.read()
	f.close()
	response = {'content': disk[returnContent:returnContent+2]}

	return jsonify(response), 200


if __name__ == '__main__':
	from argparse import ArgumentParser

	print("Type in port")
	portNum = input()
	parser = ArgumentParser()
	parser.add_argument('-p', '--port', default=portNum, type=int, help='port to listen on')
	args = parser.parse_args()
	port = args.port

	#File system creation
	filename = '127.0.0.1'+str(port)+".txt" 
	f = open(filename, "w")
	f.write("@@ @@ @@ @@ @@ @@ @@ @@ \n@@ @@ @@ @@ @@ @@ @@ @@\n@@ @@ @@ @@ @@ @@ @@ @@ ")
	f.close()

	app.run(host='127.0.0.1', port=port)