from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15, pss
from Crypto.Hash import SHA256
from time import time

import json
from urllib.parse import urlparse
from uuid import uuid4

import requests
from flask import Flask, jsonify, request
import sys

import random
import ast

"""
We want to make a blockchain such that the transactions within a block will be the FAT
Of the file. On creation, we want an array of node/content pairs to feed into transactions

When that's done we can read through the list of transactions to obtain the FAT of the file



"""

class Blockchain:
	def __init__(self):
		self.chain = []
		self.transactions = {'access': [], 'changes': []}
		self.new_block(previous_hash='1', proof=1)

	def new_block(self, proof, previous_hash):
		block = {
			'index': len(self.chain) + 1,
			'timestamp': time(),
			'transactions': self.transactions,
			'proof': proof,
			'previous_hash': previous_hash or self.hash(self.chain[-1]).hexdigest(),
		}
		self.transactions = {'access': [], 'changes': []}
		self.chain.append(block)
		return block

	def new_transaction(self, node, content, purpose):
		self.transactions['changes'].append({
			'node': node,
			'hash': content,
			'purpose': purpose
			})
		return self.last_block['index']+1

	def new_access_transaction(self, ip):
		self.transactions['access'].append({
			'ip': ip,
			'time': time()
			})
		return self.last_block['index']+1

	def validate_chain(self, chain):
		last_block = chain[0]
		current_index = 1

		while current_index < len(chain):
			block = chain[current_index]
			last_block_hash = self.hash(last_block).hexdigest()
			if block['previous_hash'] != last_block_hash:
				return False
			if not self.valid_proof(last_block['proof'], block['proof'], last_block_hash):
				return False
			last_block = block
			current_index += 1

		return True

	@property
	def last_block(self):
		return self.chain[-1]

	def proof_of_work(self, last_block):
		last_proof = last_block['proof']
		last_hash = self.hash(last_block).hexdigest()

		proof = 0
		while self.valid_proof(last_proof, proof, last_hash) is False:
			proof +=1

		return proof

	@staticmethod
	def valid_proof(last_proof, proof, last_hash):
		guess = f'{last_proof}{proof}{last_hash}'.encode()
		guess_hash = SHA256.new(guess)
		return guess_hash.hexdigest()[:3] == "000"

	@staticmethod
	def hash(block):
		block_string = str(block['index']) + str(block['timestamp']) + str(json.dumps(block['transactions'], sort_keys=True)) + str(block['proof']) + str(block['previous_hash'])
		block_string = block_string.encode()
		return SHA256.new(block_string)

